import React, { useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import {
  Bot, Code2, Globe, Database, Cpu,
  ArrowRight, CheckCircle2, Workflow, Smartphone,
  ShoppingBag, FileJson, BarChart3, Radio, ClipboardList
} from 'lucide-react';
import AnimatedSection from '../components/AnimatedSection';

const serviceCategories = [
  {
    id: 'ai',
    label: 'AI & Automation',
    icon: <Bot size={18} />,
    color: '#0057ff',
    headline: 'Intelligent Automation at Scale',
    desc: 'We deploy cutting-edge AI systems that think, learn, and act - transforming how your business operates.',
    services: [
      {
        icon: <Bot size={22} />,
        title: 'Intelligent AI Agents',
        desc: 'Task-oriented agents to handle customer support, internal queries, and routine workflows with human-like intelligence.',
        features: ['24/7 autonomous operation', 'Multi-model LLM support', 'Custom knowledge base training', 'Seamless API integration'],
      },
      {
        icon: <Workflow size={22} />,
        title: 'RPA & Workflow Automation',
        desc: 'Eliminate repetitive tasks with custom automation scripts and RPA solutions tailored precisely to your business logic.',
        features: ['Zero-code configuration', 'Cross-platform compatibility', 'Error handling & monitoring', 'ROI tracking dashboard'],
      },
    ],
  },
  {
    id: 'dev',
    label: 'Web & Mobile',
    icon: <Code2 size={18} />,
    color: '#7c3aed',
    headline: 'Full-Stack Engineering Excellence',
    desc: 'From sleek frontends to robust backends, we build digital products that users love and businesses scale on.',
    services: [
      {
        icon: <Code2 size={22} />,
        title: 'Custom Web Applications',
        desc: 'React and Next.js platforms optimized for speed, SEO, and conversion. Built for performance at any scale.',
        features: ['Server-side rendering', 'Core Web Vitals optimized', 'Progressive Web App', 'CI/CD pipeline setup'],
      },
      {
        icon: <Smartphone size={22} />,
        title: 'Mobile App Development',
        desc: 'Secure, offline-first mobile applications built for iOS and Android using React Native.',
        features: ['Cross-platform single codebase', 'Offline-first architecture', 'Push notifications', 'App Store deployment'],
      },
      {
        icon: <ShoppingBag size={22} />,
        title: 'E-commerce & Business Platforms',
        desc: 'Scalable portals designed for high traffic and seamless transactions - built to convert.',
        features: ['Payment gateway integration', 'Inventory management', 'Analytics dashboard', 'Multi-tenant support'],
      },
    ],
  },
  {
    id: 'data',
    label: 'Data Engineering',
    icon: <Database size={18} />,
    color: '#059669',
    headline: 'Data as Your Competitive Advantage',
    desc: 'Extract, transform, and act on data at scale. We turn raw information into strategic intelligence.',
    services: [
      {
        icon: <Globe size={22} />,
        title: 'Web Data Extraction',
        desc: 'High-volume store data extraction and API scraping for real-time competitive intelligence and market analysis.',
        features: ['Anti-bot bypass techniques', 'Structured data output', 'Scheduled automation', 'Cloud storage integration'],
      },
      {
        icon: <FileJson size={22} />,
        title: 'Data Cleaning & Automation',
        desc: 'Custom PDF/Excel data cleaning, formatting automation, and ETL pipelines for clean, usable data.',
        features: ['100+ format support', 'AI-powered validation', 'Duplicate detection', 'Automated reporting'],
      },
    ],
  },
  {
    id: 'research',
    label: 'Research & IoT',
    icon: <Cpu size={18} />,
    color: '#dc2626',
    headline: 'Connected Intelligence',
    desc: 'Smart systems and research automation that bridge the physical and digital worlds.',
    services: [
      {
        icon: <Radio size={22} />,
        title: 'IoT Solutions',
        desc: 'Build and deploy smart systems with connected devices and real-time data monitoring dashboards.',
        features: ['Sensor integration', 'Real-time monitoring', 'Alert systems', 'Cloud data streaming'],
      },
      {
        icon: <ClipboardList size={22} />,
        title: 'Research Automation',
        desc: 'Survey automation, data cleaning, and lead generation support for academics and enterprise researchers.',
        features: ['Survey platform integration', 'Statistical analysis', 'Visualization reports', 'Lead scoring'],
      },
      {
        icon: <BarChart3 size={22} />,
        title: 'Market Research Support',
        desc: 'Comprehensive data processing, competitive analysis, and market intelligence automation.',
        features: ['Competitor tracking', 'Sentiment analysis', 'Trend forecasting', 'Custom dashboards'],
      },
    ],
  },
];

export default function Services() {
  const categoryIds = useMemo(() => serviceCategories.map(c => c.id), []);
  const [activeTab, setActiveTab] = useState('ai');
  const stageRef = useRef(null);
  const active = serviceCategories.find(c => c.id === activeTab) || serviceCategories[0];

  useEffect(() => {
    const hash = window.location.hash.replace('#', '');
    if (hash && categoryIds.includes(hash)) {
      setActiveTab(hash);
    }
  }, [categoryIds]);

  useEffect(() => {
    const handleScroll = () => {
      const stage = stageRef.current;
      if (!stage) return;

      const rect = stage.getBoundingClientRect();
      const stickyOffset = 160;
      if (rect.top > stickyOffset || rect.bottom < stickyOffset + 80) return;

      const totalHeight = stage.offsetHeight;
      const segment = totalHeight / serviceCategories.length;
      const consumed = Math.min(
        Math.max(stickyOffset - rect.top, 0),
        Math.max(totalHeight - 1, 0)
      );

      const nextIndex = Math.min(
        serviceCategories.length - 1,
        Math.floor(consumed / segment)
      );
      const nextId = serviceCategories[nextIndex]?.id;
      if (nextId && nextId !== activeTab) {
        setActiveTab(nextId);
      }
    };

    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('resize', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleScroll);
    };
  }, [activeTab]);

  const scrollToCategory = (id) => {
    setActiveTab(id);
    const stage = stageRef.current;
    if (!stage) return;

    const index = categoryIds.indexOf(id);
    if (index === -1) return;

    const segment = stage.offsetHeight / serviceCategories.length;
    const top = stage.offsetTop + (segment * index) - 140;
    window.scrollTo({ top, behavior: 'smooth' });
  };

  return (
    <div style={{ paddingTop: 'var(--nav-height)' }}>
      <section className="dot-grid page-hero" style={{ position: 'relative', overflow: 'hidden' }}>
        <div style={{
          position: 'absolute', inset: 0,
          background: 'linear-gradient(180deg, var(--bg-primary) 0%, transparent 50%, var(--bg-primary) 100%)',
          pointerEvents: 'none',
        }} />
        <div className="container" style={{ position: 'relative' }}>
          <AnimatedSection>
            <span className="section-label">Services</span>
            <h1 style={{
              fontSize: 'clamp(44px, 7vw, 80px)',
              fontWeight: 800,
              letterSpacing: '-0.04em',
              lineHeight: 1,
              maxWidth: 760,
              marginBottom: 24,
            }}>
              Six capabilities. <span className="gradient-text">Infinite possibilities.</span>
            </h1>
            <p style={{
              fontSize: 19,
              color: 'var(--text-secondary)',
              fontWeight: 300,
              lineHeight: 1.65,
              maxWidth: 580,
            }}>
              From AI agents to IoT systems - each service is engineered for real impact, not just delivery.
            </p>
          </AnimatedSection>
        </div>
      </section>

      <section style={{ position: 'sticky', top: 'var(--nav-height)', zIndex: 100, background: 'var(--bg-primary)', borderBottom: '1px solid var(--border)' }}>
        <div className="container">
          <div style={{ display: 'flex', gap: 4, padding: '12px 0', overflowX: 'auto' }}>
            {serviceCategories.map(cat => (
              <motion.button
                key={cat.id}
                onClick={() => scrollToCategory(cat.id)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '10px 20px',
                  borderRadius: 12,
                  fontSize: 14,
                  fontWeight: 500,
                  fontFamily: 'var(--font-body)',
                  cursor: 'pointer',
                  border: 'none',
                  whiteSpace: 'nowrap',
                  background: activeTab === cat.id ? cat.color : 'transparent',
                  color: activeTab === cat.id ? '#fff' : 'var(--text-secondary)',
                  transition: 'all 0.2s ease',
                }}
              >
                <span style={{ color: activeTab === cat.id ? '#fff' : cat.color }}>{cat.icon}</span>
                {cat.label}
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      <section
        ref={stageRef}
        style={{
          height: `${serviceCategories.length * 88}vh`,
          position: 'relative',
        }}
      >
        <div
          style={{
            position: 'sticky',
            top: 'calc(var(--nav-height) + 58px)',
            minHeight: 'calc(100vh - var(--nav-height) - 72px)',
            display: 'flex',
            alignItems: 'center',
            padding: '32px 0 40px',
          }}
        >
          <div className="container" style={{ width: '100%' }}>
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 20, scale: 0.985 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -16, scale: 0.985 }}
                transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
              >
                <div className="service-header" style={{
                  background: `linear-gradient(135deg, ${active.color}10, transparent)`,
                  border: `1px solid ${active.color}25`,
                }}>
                  <div>
                    <div style={{
                      display: 'inline-flex', alignItems: 'center', gap: 8,
                      padding: '6px 14px',
                      background: `${active.color}18`,
                      border: `1px solid ${active.color}30`,
                      borderRadius: 100,
                      fontSize: 12, fontWeight: 500,
                      fontFamily: 'var(--font-mono)',
                      color: active.color,
                      textTransform: 'uppercase',
                      letterSpacing: '0.06em',
                      marginBottom: 16,
                    }}>
                      {active.icon}
                      {active.label}
                    </div>
                    <h2 style={{
                      fontFamily: 'var(--font-display)',
                      fontSize: 36,
                      fontWeight: 800,
                      letterSpacing: '-0.03em',
                      marginBottom: 12,
                    }}>
                      {active.headline}
                    </h2>
                    <p style={{ color: 'var(--text-secondary)', fontSize: 17, fontWeight: 300, lineHeight: 1.6 }}>
                      {active.desc}
                    </p>
                  </div>
                  <Link to="/contact">
                    <motion.button
                      className="btn-primary"
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.97 }}
                      style={{ whiteSpace: 'nowrap' }}
                    >
                      Get a Quote <ArrowRight size={15} />
                    </motion.button>
                  </Link>
                </div>

                <div className={`service-card-grid ${active.services.length > 2 ? 'three-up' : 'two-up'}`}>
                  {active.services.map((svc, i) => (
                    <motion.div
                      key={svc.title}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.08 }}
                      whileHover={{ y: -6 }}
                      style={{
                        background: 'rgba(255, 255, 255, 0.78)',
                        border: '1px solid var(--border)',
                        borderRadius: 20,
                        padding: 32,
                        transition: 'border-color 0.2s ease, box-shadow 0.3s ease',
                      }}
                      onMouseEnter={e => {
                        e.currentTarget.style.borderColor = active.color;
                        e.currentTarget.style.boxShadow = `0 8px 32px ${active.color}20`;
                      }}
                      onMouseLeave={e => {
                        e.currentTarget.style.borderColor = 'var(--border)';
                        e.currentTarget.style.boxShadow = 'none';
                      }}
                    >
                      <div style={{
                        width: 48, height: 48,
                        borderRadius: 14,
                        background: `${active.color}18`,
                        border: `1px solid ${active.color}30`,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        color: active.color,
                        marginBottom: 20,
                      }}>
                        {svc.icon}
                      </div>
                      <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, letterSpacing: '-0.02em', marginBottom: 10 }}>
                        {svc.title}
                      </h3>
                      <p style={{ color: 'var(--text-secondary)', fontSize: 14, lineHeight: 1.6, marginBottom: 24 }}>
                        {svc.desc}
                      </p>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                        {svc.features.map(f => (
                          <div key={f} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13 }}>
                            <CheckCircle2 size={14} color={active.color} style={{ flexShrink: 0 }} />
                            <span style={{ color: 'var(--text-secondary)' }}>{f}</span>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </section>

      <section className="section" style={{ background: 'var(--bg-secondary)', paddingTop: 0 }}>
        <div className="container">
          <AnimatedSection>
            <div className="form-shell" style={{ textAlign: 'center' }}>
              <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(30px, 5vw, 40px)', fontWeight: 800, letterSpacing: '-0.03em', marginBottom: 16 }}>
                Not sure what you need?
              </h2>
              <p style={{ color: 'var(--text-secondary)', fontSize: 17, marginBottom: 36, fontWeight: 300 }}>
                Let&apos;s have a conversation. We&apos;ll figure out the right solution together.
              </p>
              <Link to="/contact">
                <motion.button className="btn-accent" whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
                  Book a Free Consultation <ArrowRight size={15} />
                </motion.button>
              </Link>
            </div>
          </AnimatedSection>
        </div>
      </section>
    </div>
  );
}
